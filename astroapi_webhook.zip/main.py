from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

ASTROAPI_TOKEN = "866f1c5c1e412f526e7a53ec6ec55a232775f9ae"
ASTROAPI_URL = "https://astroapi.dev/api/natal"

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    payload = {
        "birth_date": data.get("birth_date"),
        "birth_time": data.get("birth_time"),
        "latitude": data.get("latitude"),
        "longitude": data.get("longitude"),
        "timezone": data.get("timezone")
    }
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Token {ASTROAPI_TOKEN}"
    }
    response = requests.post(ASTROAPI_URL, json=payload, headers=headers)
    if response.status_code == 200:
        astro_data = response.json()
        return jsonify({
            "status": "success",
            "data": astro_data
        })
    else:
        return jsonify({
            "status": "error",
            "message": response.text
        }), response.status_code

if __name__ == '__main__':
    app.run(debug=True, port=5000)